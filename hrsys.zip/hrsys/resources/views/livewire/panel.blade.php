<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; ?>

<div>
    <section class=" p-6 ">
        <livewire:leavetypecrud />
    </section>

    <section class=" p-6">
        <livewire:departmentcrud />
    </section>

</div>
